package com.chomsmp.rifteye;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.world.EntitiesLoadEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.components.CustomModelDataComponent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Transformation;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public final class RiftEyePlugin extends JavaPlugin implements Listener, TabExecutor {

    private static final String TAG = "rifteye_vfx";
    private static final String LAYER_PREFIX = "rifteye_layer_";

    /** One picture layer of the rift eye (rift, eyewhite, iris, glow, ...). */
    private static final class Layer {
        String name;
        ItemStack[] items;
        int frames;
        boolean pingPong;
        int frameTicks;
        float scale;
        Display.Billboard billboard;
        float x, y, z;
        double spin;
        float sway;
        int swayTicks;
        boolean animated;
    }

    private final Map<String, Layer> layers = new LinkedHashMap<>();
    private final Map<UUID, ItemDisplay> rifts = new HashMap<>();
    private final Map<UUID, String> layerOf = new HashMap<>();
    private BukkitTask task;
    private long tick;

    private double offsetY;
    private int brightness;
    private float viewRange;
    private int interval;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadSettings();
        getServer().getPluginManager().registerEvents(this, this);
        var cmd = getCommand("rift");
        if (cmd != null) {
            cmd.setExecutor(this);
            cmd.setTabCompleter(this);
        }
        for (World w : Bukkit.getWorlds()) {
            for (Entity e : w.getEntitiesByClass(ItemDisplay.class)) {
                track(e);
            }
        }
        task = Bukkit.getScheduler().runTaskTimer(this, this::tickLoop, 1L, 1L);
    }

    @Override
    public void onDisable() {
        if (task != null) task.cancel();
        rifts.clear();
        layerOf.clear();
    }

    // ---------------------------------------------------------------- settings

    private void loadSettings() {
        reloadConfig();
        var c = getConfig();
        offsetY = c.getDouble("offset-y", 1.0);
        brightness = c.getInt("brightness", 15);
        viewRange = (float) c.getDouble("view-range", 2.0);
        interval = Math.max(1, c.getInt("interval-ticks", 2));

        layers.clear();
        ConfigurationSection sec = c.getConfigurationSection("layers");
        if (sec == null) return;

        for (String name : sec.getKeys(false)) {
            ConfigurationSection s = sec.getConfigurationSection(name);
            if (s == null) continue;

            NamespacedKey key = NamespacedKey.fromString(s.getString("model", ""));
            if (key == null) {
                getLogger().warning("Layer '" + name + "' has an invalid model id, skipping.");
                continue;
            }

            Layer l = new Layer();
            l.name = name;
            l.frames = Math.max(1, s.getInt("frames", 1));
            l.pingPong = "PINGPONG".equalsIgnoreCase(s.getString("mode", "LOOP"));
            l.frameTicks = Math.max(1, s.getInt("frame-ticks", 4));
            l.scale = (float) s.getDouble("scale", 1.0);
            try {
                l.billboard = Display.Billboard.valueOf(s.getString("billboard", "CENTER").toUpperCase(Locale.ROOT));
            } catch (IllegalArgumentException ex) {
                l.billboard = Display.Billboard.CENTER;
            }
            l.x = (float) s.getDouble("x", 0.0);
            l.y = (float) s.getDouble("y", 0.0);
            l.z = (float) s.getDouble("z", 0.0);
            l.spin = s.getDouble("spin", 0.0);
            l.sway = (float) s.getDouble("sway", 0.0);
            l.swayTicks = Math.max(2, s.getInt("sway-ticks", 80));
            l.animated = l.spin != 0 || l.sway != 0;

            l.items = new ItemStack[l.frames];
            for (int i = 0; i < l.frames; i++) l.items[i] = makeItem(key, i);

            layers.put(name, l);
        }
    }

    /** Paper item with item_model = key and custom_model_data float[0] = frame. */
    private ItemStack makeItem(NamespacedKey key, int frame) {
        ItemStack item = new ItemStack(Material.PAPER);
        ItemMeta meta = item.getItemMeta();
        meta.setItemModel(key);
        CustomModelDataComponent cmd = meta.getCustomModelDataComponent();
        cmd.setFloats(List.of((float) frame));
        meta.setCustomModelDataComponent(cmd);
        item.setItemMeta(meta);
        return item;
    }

    // ----------------------------------------------------------------- display

    private int frameAt(Layer l, long t) {
        if (l.frames <= 1) return 0;
        long k = t / l.frameTicks;
        if (l.pingPong) {
            int period = 2 * (l.frames - 1);
            int m = (int) (k % period);
            return m < l.frames ? m : period - m;
        }
        return (int) (k % l.frames);
    }

    private void applyTransform(ItemDisplay d, Layer l, long time, int duration) {
        float angle = (float) Math.toRadians((l.spin / 20.0 * time) % 360.0);
        AxisAngle4f rot = l.billboard == Display.Billboard.FIXED
                ? new AxisAngle4f(angle, 0f, 1f, 0f)   // flat on the floor: spin around Y
                : new AxisAngle4f(angle, 0f, 0f, 1f);  // faces player: roll
        float swayX = l.sway == 0 ? 0f
                : (float) (l.sway * Math.sin(2 * Math.PI * time / l.swayTicks));

        Transformation t = new Transformation(
                new Vector3f(l.x + swayX, l.y, l.z),
                rot,
                new Vector3f(l.scale, l.scale, l.scale),
                new AxisAngle4f()
        );
        d.setInterpolationDelay(0);
        d.setInterpolationDuration(duration);
        d.setTransformation(t);
    }

    private void configure(ItemDisplay d, Layer l) {
        d.setItemStack(l.items[frameAt(l, tick)]);
        d.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.FIXED);
        d.setBillboard(l.billboard);
        d.setViewRange(viewRange);
        d.setBrightness(brightness >= 0 ? new Display.Brightness(brightness, brightness) : null);
        applyTransform(d, l, tick, 0);
    }

    private void track(Entity e) {
        if (!(e instanceof ItemDisplay d) || !d.getScoreboardTags().contains(TAG)) return;
        for (String t : d.getScoreboardTags()) {
            if (t.startsWith(LAYER_PREFIX)) {
                String name = t.substring(LAYER_PREFIX.length());
                Layer l = layers.get(name);
                if (l == null) return;
                rifts.put(d.getUniqueId(), d);
                layerOf.put(d.getUniqueId(), name);
                configure(d, l);
                return;
            }
        }
    }

    // -------------------------------------------------------------------- loop

    private void tickLoop() {
        tick++;
        rifts.values().removeIf(d -> !d.isValid());
        layerOf.keySet().retainAll(rifts.keySet());
        if (rifts.isEmpty()) return;

        for (Map.Entry<UUID, ItemDisplay> en : rifts.entrySet()) {
            Layer l = layers.get(layerOf.get(en.getKey()));
            if (l == null) continue;
            ItemDisplay d = en.getValue();
            if (l.frames > 1 && tick % l.frameTicks == 0) {
                d.setItemStack(l.items[frameAt(l, tick)]);
            }
            if (l.animated && tick % interval == 0) {
                applyTransform(d, l, tick + interval, interval);
            }
        }
    }

    @EventHandler
    public void onEntitiesLoad(EntitiesLoadEvent event) {
        for (Entity e : event.getEntities()) track(e);
    }

    // ---------------------------------------------------------------- commands

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("rift.admin")) {
            sender.sendMessage("§cYou don't have permission.");
            return true;
        }
        if (args.length == 0) {
            sender.sendMessage("§eUsage: /rift <set|remove [radius]|reload>");
            return true;
        }

        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "set" -> {
                if (!(sender instanceof Player p)) {
                    sender.sendMessage("§cPlayers only.");
                    return true;
                }
                if (layers.isEmpty()) {
                    p.sendMessage("§cNo layers in config.yml.");
                    return true;
                }
                Location loc = p.getLocation().add(0, offsetY, 0);
                loc.setYaw(0f);
                loc.setPitch(0f);
                for (Layer l : layers.values()) {
                    ItemDisplay d = p.getWorld().spawn(loc, ItemDisplay.class, e -> {
                        e.addScoreboardTag(TAG);
                        e.addScoreboardTag(LAYER_PREFIX + l.name);
                        e.setPersistent(true);
                        configure(e, l);
                    });
                    rifts.put(d.getUniqueId(), d);
                    layerOf.put(d.getUniqueId(), l.name);
                }
                p.sendMessage("§aRift eye set. It loops automatically.");
            }
            case "remove" -> {
                if (!(sender instanceof Player p)) {
                    sender.sendMessage("§cPlayers only.");
                    return true;
                }
                double r = 6;
                if (args.length > 1) {
                    try {
                        r = Math.min(64, Math.max(1, Double.parseDouble(args[1])));
                    } catch (NumberFormatException ex) {
                        p.sendMessage("§cRadius must be a number.");
                        return true;
                    }
                }
                int removed = 0;
                for (Entity e : p.getNearbyEntities(r, r, r)) {
                    if (e instanceof ItemDisplay d && d.getScoreboardTags().contains(TAG)) {
                        rifts.remove(d.getUniqueId());
                        layerOf.remove(d.getUniqueId());
                        d.remove();
                        removed++;
                    }
                }
                p.sendMessage(removed > 0
                        ? "§aRemoved the rift (" + removed + " layers)."
                        : "§cNo rift within " + (int) r + " blocks.");
            }
            case "reload" -> {
                loadSettings();
                for (Map.Entry<UUID, ItemDisplay> en : rifts.entrySet()) {
                    Layer l = layers.get(layerOf.get(en.getKey()));
                    if (l != null) configure(en.getValue(), l);
                }
                sender.sendMessage("§aRiftEye config reloaded.");
            }
            default -> sender.sendMessage("§eUsage: /rift <set|remove [radius]|reload>");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            List<String> out = new ArrayList<>();
            for (String s : List.of("set", "remove", "reload")) {
                if (s.startsWith(args[0].toLowerCase(Locale.ROOT))) out.add(s);
            }
            return out;
        }
        return List.of();
    }
}
