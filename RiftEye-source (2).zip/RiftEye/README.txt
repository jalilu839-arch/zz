RiftEye 1.1.0 - /rift set places the looping rift eye VFX where you stand.

Target:  Paper 1.21.11 (paper-api 1.21.11-R0.1-SNAPSHOT, api-version 1.21.11)
Build:   mvn clean package   (Java 21 + internet for the Paper API)
Output:  target/RiftEye-1.1.0.jar  -> server plugins/ folder

Commands (permission rift.admin, default op):
  /rift set              place the rift at your position
  /rift remove [radius]  remove the rift near you (default 6 blocks)
  /rift reload           reload config.yml

Uses the rpai_vfx models in your Chom_Smp resource pack
(rift, eyewhite, iris, glow, flare, swirl). The pack must be loaded by players.
Sizes, layer order, speed and spin are all in config.yml.
